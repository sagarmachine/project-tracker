package com.lsc.content.distribution.twitter.model;

public class TwitterImage {
    private int w;
    private int h;

    String image_type;

    public TwitterImage() {
    }


    public String getImage_type() {
        return image_type;
    }

    public void setImage_type(String image_type) {
        this.image_type = image_type;
    }

    public int getW() {
        return w;
    }

    public void setW(int w) {
        this.w = w;
    }

    public int getH() {
        return h;
    }

    public void setH(int h) {
        this.h = h;
    }
}
